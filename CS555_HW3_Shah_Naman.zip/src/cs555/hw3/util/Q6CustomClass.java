package cs555.hw3.util;

/**
 *
 * @author namanrs
 */
public class Q6CustomClass {

    int sum;
    int count;
    float percentSum;
    float percentCount;

    public Q6CustomClass(int sum, int count) {
        this.sum = sum;
        this.count = count;
    }

    public int getSum() {
        return sum;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public float getPercentSum() {
        return percentSum;
    }

    public void setPercentSum(float percentSum) {
        this.percentSum = percentSum;
    }

    public float getPercentCount() {
        return percentCount;
    }

    public void setPercentCount(float percentCount) {
        this.percentCount = percentCount;
    }

}
